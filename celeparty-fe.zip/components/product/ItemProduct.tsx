"use client";
import Image from "next/image";
import Link from "next/link";
import type { ReactNode } from "react";
import { FaStar } from "react-icons/fa";
import { FaLocationDot } from "react-icons/fa6";

interface iItemProduct {
	id?: number;
	title: string;
	image_url: string;
	price: number | string;
	rate?: string | number;
	sold?: string;
	location?: string | boolean;
	url: string;
	children?: ReactNode;
	status?: 'published' | 'unpublished' | null;
}

export default function ItemProduct(props: iItemProduct) {
	return (
		<div className="lg:p-2 lg:w-1/5 w-1/2 p-2  lg:shadow-gray-400 lg:shadow-none">
			<section className=" rounded-lg shadow-md flex flex-col justify-between h-full p-3 relative">
				{props.status && (
					<div className="absolute top-2 right-2 z-10">
						<span className={`px-2 py-1 text-xs font-bold rounded-full text-white ${props.status === 'published' ? 'bg-green-500' : 'bg-yellow-500'}`}>
							{props.status === 'published' ? 'Tiket Aktif' : 'Menunggu Persetujuan'}
						</span>
					</div>
				)}
				<div>
					<Link href={props.url} aria-label={`Lihat detail produk: ${props.title}`}>
						<div>
							<div className="relative fill-current w-full h-[100px] mx-auto text-center my-3">
								<Image
									src={props.image_url ? props.image_url : "/images/noimage.png"}
									fill
									alt={props.title ? `Gambar produk: ${props.title}` : "Gambar produk Celeparty"}
									style={{ objectFit: "cover" }}
									loading="lazy"
								/>
							</div>
							<h3 className="text-center text-sm font-medium">{props.title}</h3>
							<div className="text-c-orange text-center text-[12px] font-bold" aria-label={`Harga: ${props.price}`}>{props.price}</div>
						</div>
						<div>
							<div className="flex items-center gap-1 lg:text-[10px] text-[12px] font-medium mt-2 text-c-gray-text2">
								<FaStar className="text-[#FDD835]" aria-hidden="true" />
								<span aria-label={`Rating ${props.rate || 'belum ada'}`}>{props.rate ? props.rate : null}</span>{" "}
								{props.sold && <span className="sold-indicator" aria-label={`${props.sold} produk terjual`}>| {props.sold} Terjual</span>}
							</div>
							{props.location ? (
								<div className="flex gap-1 items-center text-[12px] lg:text-[10px] mt-2 text-c-gray-text2 capitalize" aria-label={`Lokasi: ${props.location}`}>
									<FaLocationDot aria-hidden="true" /> {props.location}
								</div>
							) : null}
						</div>
					</Link>
				</div>
				{props.children}
			</section>
		</div>
	);
}
