"use client";
import React, { Children, ReactNode } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";

import "slick-carousel/slick/slick-theme.css";

import ErrorNetwork from "@/components/ErrorNetwork";
import { axiosData, getData } from "@/lib/services";
import { useQuery } from "@tanstack/react-query";
import Image from "next/image";
import Link from "next/link";

function ItemSlide(props: any) {
	return (
		<div className="w-full h-48 sm:h-64 lg:h-80 relative bg-gradient-to-r from-violet-600 to-indigo-600 rounded-lg overflow-hidden">
			<Link href={props.link} aria-label={`Banner: ${props.title || 'Event promotion'}`}>
				<Image
					src={props.image}
					fill
					alt={props.title ? `Banner promosi: ${props.title}` : "Banner promosi event Celeparty"}
					className="object-cover hover:scale-105 transition-transform duration-300"
					loading="lazy"
				/>
			</Link>
		</div>
	);
}

const settings = {
	arrow: true,
	dots: true,
	infinite: true,
	speed: 1000,
	slidesToShow: 1,
	slidesToScroll: 1,
	autoplay: true, // aktifkan auto play
	autoplaySpeed: 7000, // delay per slide (5 detik)
	cssEase: "linear",
	pauseOnHover: true, // berhenti kalau kursor di atas
	responsive: [
		{
			breakpoint: 1024,
			settings: {
				arrows: true,
				dots: true,
			},
		},
		{
			breakpoint: 768,
			settings: {
				arrows: false,
				dots: true,
			},
		},
	],
};

export default function MainBanner() {
	const getQuery = async () => {
		return await axiosData("GET", "/api/banners?populate=*");
	};
	const query = useQuery({
		queryKey: ["banner"],
		queryFn: getQuery,
	});

	if (query.isLoading) {
		return (
			<div className="relative flex justify-center">
				<div className="animate-pulse w-full h-48 sm:h-64 lg:h-80 bg-c-gray-200 rounded-lg"></div>
			</div>
		);
	}

	if (query.isError) {
		return <ErrorNetwork />;
	}
	const dataContent = query?.data.data;

	return (
		<div className="mainslider rounded-lg w-full overflow-hidden relative shadow-soft" role="region" aria-label="Banner carousel">
			{dataContent?.length > 1 ? (
				<Slider {...settings} aria-label="Event banners carousel">
					{dataContent?.map((item: any) => (
						<ItemSlide
							key={item.id}
							link={item.url ? item.url : "/"}
							image={item.image ? process.env.BASE_API + item.image.url : "/images/noimage.png"}
							title={item.title}
						/>
					))}
				</Slider>
			) : dataContent?.length === 1 ? (
				<div className="w-full h-48 sm:h-64 lg:h-80 relative bg-gradient-to-r from-violet-600 to-indigo-600 rounded-lg overflow-hidden">
					<Link href={dataContent[0].url ? dataContent[0].url : "/"} aria-label={`Banner: ${dataContent[0].title || 'Event promotion'}`}>
						<Image
							src={
								dataContent[0].image
									? process.env.BASE_API + dataContent[0].image.url
									: "/images/noimage.png"
							}
							fill
							alt={dataContent[0].title ? `Banner promosi: ${dataContent[0].title}` : "Banner promosi event Celeparty"}
							className="object-cover hover:scale-105 transition-transform duration-300"
							loading="lazy"
						/>
					</Link>
				</div>
			) : (
				<></>
			)}
		</div>
	);
}
